UrqW

UrqW is an open source engine for text-based games and interactive fiction, available free of charge.

To run the web application, open the index.html file in your browser.

- Home page: https://urqw.github.io/UrqW/
- Source code: https://github.com/urqw/UrqW/
- Version: 1.1.0-beta
- Build date: 2026-08-21
- Commit hash: 37e03b65efc58af70e8811a119f25b1ab5fda5a5
