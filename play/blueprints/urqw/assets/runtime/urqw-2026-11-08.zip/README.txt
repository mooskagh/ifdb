UrqW

UrqW is an open source engine for text-based games and interactive fiction, available free of charge.

To run the web application, open the index.html file in your browser.

- Home page: https://urqw.github.io/UrqW/
- Source code: https://github.com/urqw/UrqW/
- Version: 2.0.0-beta
- Build date: 2026-11-08
- Commit hash: cbab60a6ffa350dc8c73173a2f9baaef300f0c70
